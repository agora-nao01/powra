# Micronode Android — 0.1-alpha

Protótipo inicial Android-first para a ideia Micronode.

## O que funciona nesta versão
- Interface inicial da Micronode.
- Botão de upload usando o seletor de imagens do Android.
- Imagens importadas são copiadas para `data/packs`.
- Lista de imagens reconhecidas (PNG, JPG, JPEG, WebP, GIF, BMP e AVIF).
- Configuração de build de APK debug.

## O que ainda não existe
- Editor visual de nodes.
- Linguagem Assembly interna dos nodes.
- Node to Code.
- Compiladores/geradores de C, C++, Java, Kotlin, C#, Swift ou Objective-C.
- Runtime de jogos, cenas, física e exportação de jogos.

## Pasta data/packs
O app cria a pasta:
`Android/data/com.agoranao.micronode/files/data/packs/`

O caminho completo depende do armazenamento do dispositivo. Essa pasta é específica do app e pode ser acessada por USB/PC; alguns gerenciadores de arquivos Android bloqueiam o acesso a `Android/data`.

O app não inclui imagens padrão inventadas. Você pode importar as suas imagens pelo botão da interface.

## Gerar APK
Abra o projeto no Android Studio com Android SDK 35 e JDK 17 e compile a variante `debug`.

Alternativamente, envie o projeto a um repositório GitHub e execute o workflow `Build Micronode APK` em Actions. O artefato `Micronode-debug-apk` conterá `app-debug.apk`.

## Requisitos
- Android Studio / Gradle
- JDK 17
- Android SDK Platform 35
- Android 6.0 (API 23) ou superior

## Identificação
- Nome: Micronode
- Package: `com.agoranao.micronode`
- Versão: `0.1-alpha`
