package com.agoranao.micronode;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 4101;
    private File packsDir;
    private LinearLayout packList;
    private TextView status;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Editable/copyable app-specific folder:
        // Android/data/com.agoranao.micronode/files/data/packs/
        File root = getExternalFilesDir(null);
        if (root == null) root = getFilesDir();
        packsDir = new File(root, "data/packs");
        if (!packsDir.exists()) packsDir.mkdirs();

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(24), dp(20), dp(20));
        page.setBackgroundColor(Color.rgb(18, 22, 29));

        TextView title = new TextView(this);
        title.setText("MICRONODE");
        title.setTextSize(28);
        title.setTextColor(Color.rgb(118, 228, 247));
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setTypeface(null, 1);
        page.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Micro game engine • Android-first • NodeScript");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(13);
        subtitle.setPadding(0, dp(4), 0, dp(20));
        page.addView(subtitle, matchWrap());

        TextView statusTitle = new TextView(this);
        statusTitle.setText("PROJETO");
        statusTitle.setTextColor(Color.WHITE);
        statusTitle.setTextSize(18);
        statusTitle.setTypeface(null, 1);
        page.addView(statusTitle, matchWrap());

        TextView description = new TextView(this);
        description.setText("Versão 0.1-alpha\nProtótipo inicial da interface. O editor visual de nodes e o compilador Node to Code ainda não estão implementados.");
        description.setTextColor(Color.rgb(205, 211, 220));
        description.setTextSize(14);
        description.setPadding(0, dp(8), 0, dp(18));
        page.addView(description, matchWrap());

        Button upload = makeButton("＋  Enviar imagem para data/packs");
        upload.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, PICK_IMAGE);
        });
        page.addView(upload, matchWrap());

        Button refresh = makeButton("Atualizar lista de imagens");
        refresh.setOnClickListener(v -> refreshPacks());
        LinearLayout.LayoutParams refreshLp = matchWrap();
        refreshLp.topMargin = dp(8);
        page.addView(refresh, refreshLp);

        TextView folder = new TextView(this);
        folder.setText("PASTA DOS PACKS\n" + packsDir.getAbsolutePath());
        folder.setTextColor(Color.rgb(118, 228, 247));
        folder.setTextSize(12);
        folder.setPadding(0, dp(18), 0, dp(12));
        page.addView(folder, matchWrap());

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(13);
        page.addView(status, matchWrap());

        TextView listTitle = new TextView(this);
        listTitle.setText("IMAGENS DISPONÍVEIS");
        listTitle.setTextColor(Color.WHITE);
        listTitle.setTextSize(16);
        listTitle.setTypeface(null, 1);
        listTitle.setPadding(0, dp(20), 0, dp(8));
        page.addView(listTitle, matchWrap());

        packList = new LinearLayout(this);
        packList.setOrientation(LinearLayout.VERTICAL);
        page.addView(packList, matchWrap());

        TextView footer = new TextView(this);
        footer.setText("NodeScript → Assembly interno → sua decisão de compilar → Node to Code → compilador");
        footer.setTextColor(Color.GRAY);
        footer.setTextSize(12);
        footer.setPadding(0, dp(24), 0, dp(8));
        page.addView(footer, matchWrap());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(page);
        setContentView(scroll);
        refreshPacks();
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.rgb(18, 22, 29));
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(118, 228, 247)));
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGE || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;

        String originalName = getDisplayName(uri);
        String safeName = sanitize(originalName);
        if (!safeName.contains(".")) safeName += ".img";
        File destination = new File(packsDir, safeName);
        String base = safeName;
        int i = 2;
        while (destination.exists()) {
            int dot = base.lastIndexOf('.');
            String name = dot > 0 ? base.substring(0, dot) : base;
            String ext = dot > 0 ? base.substring(dot) : "";
            destination = new File(packsDir, name + "_" + i + ext);
            i++;
        }

        try (InputStream in = getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(destination)) {
            if (in == null) throw new IOException("Não foi possível abrir a imagem");
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            Toast.makeText(this, "Imagem adicionada aos packs", Toast.LENGTH_LONG).show();
            status.setText("Última imagem: " + destination.getName());
            refreshPacks();
        } catch (Exception e) {
            Toast.makeText(this, "Falha ao importar: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String getDisplayName(Uri uri) {
        String name = "image_" + System.currentTimeMillis() + ".png";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) name = cursor.getString(index);
            }
        } catch (Exception ignored) {}
        return name;
    }

    private String sanitize(String name) {
        String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
        if (safe.isEmpty()) safe = "image_" + System.currentTimeMillis() + ".png";
        return safe;
    }

    private void refreshPacks() {
        if (packList == null) return;
        packList.removeAllViews();
        File[] files = packsDir.listFiles();
        int count = 0;
        if (files != null) {
            for (File f : files) {
                if (!f.isFile()) continue;
                String n = f.getName().toLowerCase(Locale.ROOT);
                if (!(n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".jpeg") ||
                      n.endsWith(".webp") || n.endsWith(".gif") || n.endsWith(".bmp") ||
                      n.endsWith(".avif"))) continue;
                TextView item = new TextView(this);
                item.setText("•  " + f.getName() + "  (" + readableSize(f.length()) + ")");
                item.setTextColor(Color.rgb(220, 225, 233));
                item.setTextSize(14);
                item.setPadding(dp(8), dp(10), dp(8), dp(10));
                packList.addView(item, matchWrap());
                count++;
            }
        }
        if (count == 0) {
            TextView empty = new TextView(this);
            empty.setText("Nenhuma imagem ainda. Use “Enviar imagem” para adicionar a primeira.");
            empty.setTextColor(Color.LTGRAY);
            empty.setTextSize(13);
            packList.addView(empty, matchWrap());
        }
        if (status != null) status.setText(count + " imagem(ns) encontrada(s) em data/packs.");
    }

    private String readableSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format(Locale.ROOT, "%.1f KB", bytes / 1024.0);
        return String.format(Locale.ROOT, "%.1f MB", bytes / (1024.0 * 1024.0));
    }
}
