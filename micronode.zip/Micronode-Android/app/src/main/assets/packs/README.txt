Micronode packs

Coloque aqui as imagens padrão que a engine venha a usar.
Na primeira versão, imagens enviadas pelo botão de upload são copiadas para:
Android/data/com.agoranao.micronode/files/data/packs/

Este diretório de assets é incorporado ao APK e não é editável diretamente após a instalação.
A pasta data/packs criada em armazenamento externo específico do app é a cópia editável.
